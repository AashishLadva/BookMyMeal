import { createContext } from "react";
import { toastStyle } from "../Constants/general";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import dayjs from "dayjs";
import { TbAlignBoxCenterMiddleFilled } from "react-icons/tb";
import { FaHome } from "react-icons/fa";
import { RiLockPasswordFill } from "react-icons/ri";
import { PiWarningCircleFill } from "react-icons/pi";
import { MdPrivacyTip } from "react-icons/md";

export const contextProvider = createContext({
  validateUserEmail: () => {},
  validatePassword: () => {},
  validateChangePassword: () => {},
  isWeekend: () => {},
  navItems: [],
  isBookingDinner: () => {},
  isBookingLunch: () => {}
});
const validateUserEmail = (userEmail) => {
  const userEmailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!userEmail) {
    toast.error("👤 Useremail is required!", toastStyle);
    return false;
  } else if (!userEmailPattern.test(userEmail)) {
    toast.error("👤 Please enter a valid email address.", toastStyle);
    return false;
  }
  return true;
};
const validatePassword = (password) => {
  const passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,16}$/;
  if (!password) {
    toast.error("🔒 Password is required!", toastStyle);
    return false;
  } else if (!passwordPattern.test(password)) {
    toast.error(
      "🔒 Password must be 8-16 characters, include uppercase, lowercase, and a number",
      toastStyle
    );
    return false;
  }
  return true;
};

const validateChangePassword = (oldPassword, password, confirmPassword) => {
  const passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,16}$/;
  if (!oldPassword) {
    toast.error("🔒 old Password is required", toastStyle);
    return false;
  } else if (!password) {
    toast.error("🔒 New Password is required", toastStyle);
    return false;
  } else if (password == oldPassword) {
    toast.error(
      "🔒 your new password cannot be the same as your old password",
      toastStyle
    );
    return false;
  } else if (!confirmPassword) {
    toast.error("🔒Confirm Password is required", toastStyle);
    return false;
  } else if (password !== confirmPassword) {
    toast.error(
      "🔒 Please fill same Password and Confirm Password",
      toastStyle
    );
    return false;
  } else if (!passwordPattern.test(password)) {
    toast.error(
      "🔒 Password must be 8-16 characters, include uppercase, lowercase, and a number",
      toastStyle
    );
    return false;
  }
  return true;
};

const holidays = [
  dayjs("2024-01-26"),
  dayjs("2024-08-15"),
  dayjs("2024-11-02"),
  dayjs("2024-12-25"),
  dayjs("2024-11-12"),
  dayjs("2024-03-29"),
  dayjs("2024-01-01"),
  dayjs("2024-10-23"),
  dayjs("2024-01-14"),
];

const isWeekend = (date) => {
  const day = date.day();
  return (
    day === 0 ||
    day === 6 ||
    holidays.some((holiday) => holiday.isSame(date, "day"))
  );
};
const navItems = [
  { label: "Home", icon: <FaHome />, route: "" },
  {
    label: "Change Password",
    icon: <RiLockPasswordFill />,
    route: "changePassword",
  },
  { label: "About", icon: <PiWarningCircleFill />, route: "about" },
  {
    label: "Terms And Conditions",
    icon: <TbAlignBoxCenterMiddleFilled />,
    route: "termsAndCondition",
  },
  { label: "Privacy Policy", icon: <MdPrivacyTip />, route: "privacyPolicy" },
];

const isBookingDinner = () => {
  const now = dayjs();
  const cutoffTime = dayjs().hour(15).minute(0);
  return now.isBefore(cutoffTime);
};

const isBookingLunch = () => {
  const now = dayjs();
  const cutoffTime = dayjs().hour(22).minute(0);
  return now.isBefore(cutoffTime);
};

const ValidationsAndItemsProvider = ({ children }) => {
  
  return (
    <contextProvider.Provider
      value={{
        validateUserEmail,
        validatePassword,
        validateChangePassword,
        isWeekend,
        navItems,
        isBookingDinner,
        isBookingLunch,
        
      }}
    >
      {children}
    </contextProvider.Provider>
  );
};

export default ValidationsAndItemsProvider;
